'''
Nom william bouchard
Date 2023-11-30
Description Pool hockey
'''

from menu import *

# Début du programme principal
if __name__ == '__main__':
    # Création de la fenêtre principale
    w = Tk()

    # Configuration de la fenêtre principale
    bg = "light grey"
    fg = "black"
    w.configure(bg=bg)
    w.title("Pool Hockey 2023-2024 - Collège d'alma")
    w.geometry("800x600")
    w.iconbitmap("..\etc\image\Image1.ico")
    w.resizable(False, False)

    create_menu(w)

    # frame
    frm = Frame(w, bg=bg)
    frm.grid(row=0, column=0, sticky='ew')
    w.grid_rowconfigure(0, weight=1)
    w.grid_columnconfigure(0, weight=1)

    # Création et positionnement du label lblTitre
    lblTitre = Label(frm, text="Joueur", font=("Courrier", 30), fg=fg, bg=bg)
    lblTitre.grid(row=0, column=0, columnspan=2, pady=10)

    # Création et positionnement du label lblTexte
    texte = "(Choisir 24 joueurs en cochants la case a gauche de leur nom)"
    lblTexte = Label(frm, text=texte, font=("Courrier", 10), fg=fg, bg=bg)
    lblTexte.grid(row=1, column=0, columnspan=2)

    # Création du Canvas
    canvas = Canvas(frm, width=800, height=2, bg=bg, bd=0, highlightthickness=0)
    canvas.grid(row=2, column=0, columnspan=2, pady=10)

    # Création de la ligne
    canvas.create_line(0, 0, w.winfo_screenwidth(), 0, fill="black")

    # Création et positionnement du label lblTexte
    texte = "<< En cours de construction >>"
    lblTexte = Label(frm, text=texte, font=("Courrier", 30), fg='red', bg=bg)
    lblTexte.grid(row=3, column=0, columnspan=2)

    # Création du Canvas
    canvas = Canvas(frm, width=800, height=2, bg=bg, bd=0, highlightthickness=0)
    canvas.grid(row=4, column=0, columnspan=2, pady=10)
    canvas.create_line(0, 0, w.winfo_screenwidth(), 0, fill="black")

    # frame pour bouton
    frm1 = Frame(frm, bg=bg)
    frm1.grid(row=5, column=0, columnspan=2, pady=10)

    # Création et positionnement du bouton sauvegarder, modifier, réinitialiser dans le Frame
    btnSauvegarder = Button(frm1, text="Sauvegarder", font=("Courrier", 12), fg=fg, bg=bg, width=20)
    btnSauvegarder.grid(row=0, column=0, pady=10, padx=10)

    btnModifier = Button(frm1, text="Modifier", font=("Courrier", 12), fg=fg, bg=bg, width=20)
    btnModifier.grid(row=0, column=1, pady=10, padx=10)

    btnReinitialiser = Button(frm1, text="Réinitialiser", font=("Courrier", 12), fg=fg, bg=bg, width=20)
    btnReinitialiser.grid(row=0, column=2, pady=10, padx=10)

    # Boucle principale
    w.mainloop()
